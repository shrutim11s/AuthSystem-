package com.AuthSystemRBAC.AuthSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
